import { useEffect, useState } from "react";

const Grocery =()=>{
    const [entry,setEntry] = useState("");
    const [people,setPeople] = useState([]);
    const [add,setAdd] = useState(false);
    const [clear,setClear] = useState(false);
    const [edit,setEdit] =  useState(false);
    const handleSubmit =(e)=>{
     e.preventDefault();
     if(entry){
         let newpeople = [entry];
         setPeople([...people,entry]);
        setAdd(true);
        setEntry("");
     }
    
    }
    useEffect(()=>{
       let timeout= setTimeout(()=>{
         setAdd(false);
         setClear(false);
        },3000)
        return ()=>clearTimeout(timeout);
    },[add]);
    const remove =(id)=>{
     let newpeople =  people.filter((item,index)=>index!=id);
     setPeople(newpeople);
     setClear(true);
    }
    
    return<section className="sec">
           <h2>Grocery Bud</h2>
           <p>{(add&&`data Added`)||(clear&&`item removed`)}</p>
           
    <form>
        <input type="text" value={entry} onChange={(e)=>setEntry(e.target.value)}></input>
        <button type="submit" onClick={handleSubmit}>Submit</button>
    </form>
         {people.map((item,index)=>{
          return <article>
             <p>{item}</p>
             <button type="button">edit</button>
             <button type="button" onClick={()=>remove(index)}>remove</button>

             </article>
         })}
     </section>
}

export default Grocery;
