import { useEffect, useRef } from "react";
import { useGlobalContext } from "./stripe";
import sublinks from "./data";
import { link } from "fs";
const Submenu =()=>{
    const {isSubMenu,location} = useGlobalContext();
     const subMenuContainer = useRef(null);
    // const {page,links} = pageItem;
    // const pageLink = sublinks.find((link)=>link.page=="company")
    // console.log(pageLink);
    useEffect(()=>{
     const {center,bottom} =location;
    
        subMenuContainer.current.style.left=`${center}px`;
        subMenuContainer.current.style.top=`${bottom}px`;

    },[location])
    return<div className="container">
        <div className="row">
            <div className={isSubMenu?`col bg-white p-4 submenu d-none d-md-block `:`d-none`} ref={subMenuContainer}>
                 
            </div>
        </div>

    </div>
}
export default Submenu;