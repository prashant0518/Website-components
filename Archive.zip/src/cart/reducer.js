const reducer =(state,action)=>{
if(action.type==="Loading"){
    return {...state,loading:true}
}
if(action.type==="Display"){
    return {...state,loading:false,cart:action.payload}
}
if(action.type==="Clear_Cart"){
    return {...state,cart:[]}
}
if(action.type==="Remove_Item"){
    return {...state,cart:state.cart.filter((item)=>item.id!==action.payload)}
}
// if(action.type==="Change"){
//    let cartItem = state.cart.map((itemc,index)=>{
//      if(itemc.id==action.payload.id){
//         if(action.payload.type=='inc'){
           
//             return {...itemc,amount:itemc.amount+1}
//         }
//         if(action.payload.type=='dec'){
        
//              return {...itemc,amount:itemc.amount-1}
//          }
//          return itemc;
//      }
//    })
// return{...state,cart:cartItem}
// }
if(action.type==="Increase"){
    let tempCart = state.cart.map((item)=>{
        if(item.id==action.payload){
            return{...item,amount:item.amount+1}
        }
    })
    return {...state,cart:tempCart}
}
return state;
}

export default reducer;