 const Home =()=>{
    return <h1>Projects</h1>
}

export default Home;